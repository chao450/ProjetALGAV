/* Génère un fichier qui sera utiliser par graphviz qui renvoie un graph.png
 * command : dot -Tpng -onom.png nom.dot
 * Auteur : LIN Chao
 */

package graphiviz;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import tries.patricia.Node;
import tries.patricia.Patricia;

public class GraphVizGenerate {
	private static List<String> generateTab(Patricia p, List<String> list, String prefixe){
		String strtable = "\tstruct_";
		// les [,],; posent des problemes de compilation pour generer le graph
		if(prefixe.contains("[") || prefixe.contains("]") || prefixe.contains(";")){
			if(prefixe.contains("[")){
				prefixe=prefixe.replace("[", "crochet_ouvert");
			}
			if(prefixe.contains("]")){
				prefixe=prefixe.replace("]", "crochet_fermer");
			}
			if(prefixe.contains(";")){
				prefixe=prefixe.replace(";", "point_virgule");
			}
		}
		strtable+=" [label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\"> <TR>";
		for(Node n : p.getTab()){
			if(n!=null){
				strtable+="<TD PORT=\""+n.getClef()+"\">"+n.getClef()+"</TD>";
			}
		}
		strtable+="</TR></TABLE>>];";
		list.add(strtable);
		for(Node n : p.getTab()){
			if(n!=null){
				if(n.getFils()!=null){
					generateTab(n.getFils(),list,prefixe+n.getClef());
				}
			}
		}
		return list;
	}
	
	public static List<String> generateArrow(Patricia pat, List<String> list, String prefixe){
		String str="\tstruct_";
		if(pat.getPere()!=null){
			if(prefixe.contains("[") || prefixe.contains("]") || prefixe.contains(";")){
				if(prefixe.contains("[")){
					prefixe=prefixe.replace("[", "crochet_ouvert");
				}
				if(prefixe.contains("]")){
					prefixe=prefixe.replace("]", "crochet_fermer");
				}
				if(prefixe.contains(";")){
					prefixe=prefixe.replace(";", "point_virgule");
				}
			}
			str+=prefixe;
		}
		for(Node n : pat.getTab()){
			if(n!=null){
				if(n.getFils()!=null){
					if(n.getClef().contains("[") || n.getClef().contains("]") || n.getClef().contains(";")){
						if(n.getClef().contains("[")){
							String arrow=str+":"+n.getClef().replace("[", "crochet_ouvert")+"->"+"struct_"+prefixe+n.getClef().replace("[", "crochet_ouvert")+";";
							list.add(arrow);
						}
						if(n.getClef().contains("]")){
							String arrow=str+":"+n.getClef().replace("]", "crochet_fermer")+"->"+"struct_"+prefixe+n.getClef().replace("]", "crochet_fermer")+";";
							list.add(arrow);
						}
						if(n.getClef().contains(";")){
							String arrow=str+":"+n.getClef().replace(";", "point_virgule")+"->"+"struct_"+prefixe+n.getClef().replace(";", "point_virgule")+";";
							list.add(arrow);
						}
					}
					else{
						String arrow=str+":"+n.getClef()+"->"+"struct_"+prefixe+n.getClef()+";";
						list.add(arrow);
					}
				}
			}
		}
		for(Node n : pat.getTab()){
			if(n!=null){
				if(n.getFils()!=null){
					generateArrow(n.getFils(),list,prefixe+n.getClef());
				}
			}
		}
		return list;
	}
	
	public static void generateGraph(Patricia pat, String filename){
		try {
			File file = new File("GraphViz/"+filename+".dot");
			PrintWriter pw = new PrintWriter( new BufferedWriter( new FileWriter(file)));
			pw.println("digraph G {");
			pw.println("\tnode [shape=plaintext]");
			List<String> s = generateTab(pat,new ArrayList<String>(),"");
			s = generateArrow(pat, s, "");
			for(String line : s){
				pw.println(line);
			}
			pw.println("}");
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
