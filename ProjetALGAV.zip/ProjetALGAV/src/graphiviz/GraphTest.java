package graphiviz;

import lecture.Lecture;
import tries.patricia.Patricia;

public class GraphTest {
	public static void main(String[] args){
		//Generation du graphe de Shakespeare échoué, la taille de l'image est trop grande
		Patricia shakespeare = Lecture.lectureSuccessifPatricia();
		GraphVizGenerate.generateGraph(shakespeare, "Shakespeare");
		/*
		String exempleDeBase = 
				"A quel genial professeur de dactylographie sommes nous redevables de la superbe "
				+ "phrase ci dessous, un modele du genre, que toute dactylo connait par coeur "
				+ "puisque elle fait appel a chacune des touches du clavier de la machine a ecrire ?";
		Patricia p = new Patricia();
		p.insertPhrase(exempleDeBase);
		GraphVizGenerate.generateGraph(p, "exemple_de_base_sans_nil");
		
		Patricia p2 = new Patricia();
		p2.insert("p");
		p2.insert("ph");
		p2.insert("pho");
		p2.insert("phoa");
		p2.insert("phoab");
		p2.insert("phoabc");
		GraphVizGenerate.generateGraph(p2, "test_sans_nil");*/
	}
}
