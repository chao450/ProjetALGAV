package graphiviz;

import tries.hybride.Hybride;

public class GraphTestHybride {
	public static void main(String[] args){
		//Generation du graphe de Shakespeare échoué, la taille de l'image est trop grande
		//Hybride shakespeare = Lecture.lectureSuccessifHybride();
		//GraphVizGenerate.generateGraph(shakespeare, "Shakespeare");
		
		String exempleDeBase = 
				"A quel genial professeur de dactylographie sommes nous redevables de la superbe "
				+ "phrase ci dessous, un modele du genre, que toute dactylo connait par coeur "
				+ "puisque elle fait appel a chacune des touches du clavier de la machine a ecrire ?";
		Hybride h = new Hybride();
		h.insertPhrase(exempleDeBase);
		GraphVizGenerate.generateGraph(h, "exemple_de_base_sans_nil_hybride");
		
		Hybride h2 = new Hybride();
		h2.resetCpt();
		h2.ajoutMot("p");
		h2.ajoutMot("ph");
		h2.ajoutMot("pho");
		h2.ajoutMot("phoa");
		h2.ajoutMot("phoab");
		h2.ajoutMot("phoabc");
		GraphVizGenerate.generateGraph(h2, "test_sans_nil_hybride");
	}
}