package tries.patricia;

public class Node {
	private String clef;
	private Patricia fils;
	
	public Node(String clef){
		this.clef=clef;
		fils=null;
	}
	
	public String getClef(){
		return clef;
	}
	
	public int getLength(){
		return clef.length();
	}
	
	public Patricia getFils(){
		return fils;
	}
	
	public void setClef(String c){
		clef=c;
	}
	
	public void setFils(Patricia f){
		fils=f;
	}
}
