package tries.patricia.test;

import tries.patricia.Patricia;

public class PatriciaTest {
	public static void main(String args[]){
		String exempleDeBase = 
				"A quel genial professeur de dactylographie sommes nous redevables de la superbe "
				+ "phrase ci dessous, un modele du genre, que toute dactylo connait par coeur "
				+ "puisque elle fait appel a chacune des touches du clavier de la machine a ecrire ?";
		Patricia p = new Patricia();
		p.insertPhrase(exempleDeBase);
		p.printTab();
		System.out.println(p.comptageMots());
		// Test pour fusion + suppression
		/*System.out.println("\n------------------\n");
		Patricia p2 = new Patricia();
		p2.insert("p");
		p2.insert("ph");
		p2.insert("pho");
		p2.insert("phoa");
		p2.insert("phoab");
		p2.insert("phoabc");
		p.fusion(p2);
		p.suppression("pho");
		p.printTab();
		p.profondeurMoyenne();*/
	}
}
