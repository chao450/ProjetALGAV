package tries.hybride.test;

import tries.hybride.Hybride;

public class HybrideTest {
	public static void main(String args[]){
		Hybride h = new Hybride();
		String exempleDeBase = 
				"A quel genial professeur de dactylographie sommes nous redevables de la superbe "
				+ "phrase ci dessous, un modele du genre, que toute dactylo connait par coeur "
				+ "puisque elle fait appel a chacune des touches du clavier de la machine a ecrire ?";
		h.insertPhrase(exempleDeBase);
		/*for(String i : h.listeMot()){
			System.out.println(i);
		}*/
		System.out.println("----");
		Hybride h2 = new Hybride();
		h2.ajoutMot("un");
		h2.ajoutMot("une");
		h2.ajoutMot("unee");
		h2.suppression("une");
		for(String i : h2.listeMot()){
			System.out.println(i);
		}
	}
}
