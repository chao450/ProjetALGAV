package tries.hybride;

/*
 * Tries Hybrides : LIN Chao
 * 
 * 
 */
import java.util.ArrayList;
import java.util.List;

public class Hybride {
	private int val;
	private char alpha;
	private Hybride inf;
	private Hybride eq;
	private Hybride sup;
	public static int cpt=0;
	
	public Hybride(int val, char alpha, Hybride inf, Hybride eq, Hybride sup){
		this.val = val;
		this.alpha = alpha;
		this.inf = inf;
		this.eq = eq;
		this.sup = sup;
	}
	
	public Hybride(){
		this(-1,' ',null,null,null);
	}
	
	//getter
	public int getVal(){
		return val;
	}
	
	public char getAlpha(){
		return alpha;
	}
	
	public Hybride getInf(){
		return inf;
	}
	
	public Hybride getEq(){
		return eq;
	}
	
	public Hybride getSup(){
		return sup;
	}
	
	// setter
	public void setVal(int val){
		this.val = val;
	}
	
	public void setAlpha(char alpha){
		this.alpha=alpha;
	}
	
	public void setInf(Hybride inf){
		this.inf=inf;
	}
	
	public void setEq(Hybride eq){
		this.eq=eq;
	}
	
	public void setSup(Hybride sup){
		this.sup=sup;
	}
	
	public boolean estVide(){
		return (getAlpha()==' ');
	}
	
	public boolean estFeuille(){
		return inf==null&&eq==null&&sup==null;
	}
	
	public void ajoutMot(String mot){
		if(mot.length()==0){
			return;
		}
		if(estVide()){
			setAlpha(mot.charAt(0));
			if(mot.length()==1){
				setVal(cpt++);
			}
			else{
				setEq(new Hybride());
				getEq().ajoutMot(mot.substring(1));
			}
			return;
		}
		char c = mot.charAt(0);
		if (c<getAlpha()){
			if(getInf()!=null){
				getInf().ajoutMot(mot);
			}
			else{
				setInf(new Hybride());
				getInf().ajoutMot(mot);
			}
			return;
		}
		if(c>getAlpha()){
			if(getSup()!=null){
				getSup().ajoutMot(mot);
			}
			else{
				setSup(new Hybride());
				getSup().ajoutMot(mot);
			}
			return;
		}
		if(getEq()!=null){
			getEq().ajoutMot(mot.substring(1));
		}
		else{
			setEq(new Hybride());
			getEq().ajoutMot(mot.substring(1));
		}
		return;
	}
	
	public void insertPhrase(String phrase) {
		int debutMot = 0;
		for (int i = 0; i < phrase.length(); i++) {
			if (phrase.charAt(i) == ' ') {
				String mot = phrase.substring(debutMot, i);
				if (mot.contains(",")) {
					mot = mot.replace(",", "");
					this.ajoutMot(",");
				}
				this.ajoutMot(mot);
				debutMot = i + 1;
			}
		}
		this.ajoutMot(phrase.substring(debutMot, phrase.length()));
	}
	
	public boolean recherche(String mot){
		char c = mot.charAt(0);
		if(c<alpha){
			if(inf!=null){
				return inf.recherche(mot);
			}
			return false;
		}
		if(c>alpha){
			if(sup!=null){
				return sup.recherche(mot);
			}
			return false;
		}
		if(mot.length()==1){
			if(val>=0){
				return true;
			}
			return false;
		}
		if(eq!=null){
			return eq.recherche(mot.substring(1));
		}
		return false;
	}
	
	public int comptageMot(){
		int c = 0;
		if(val>=0){
			c++;
		}
		if(inf!=null){
			c+=inf.comptageMot();
		}
		if(eq!=null){
			c+=eq.comptageMot();
		}
		if(sup!=null){
			c+=sup.comptageMot();
		}
		return c;
	}

	private void trouveMot(String prefixe, List<String> list){
		if(inf!=null){
			inf.trouveMot(prefixe, list);
		}
		if(val>-1){
			list.add(prefixe+alpha+" "+val);
		}
		if(eq!=null){
			eq.trouveMot(prefixe+alpha, list);
		}
		if(sup!=null){
			sup.trouveMot(prefixe, list);
		}
	}
	
	public List<String> listeMot(){
		List<String> list = new ArrayList<String>();
		trouveMot("",list);
		return list;
	}
	
	public int comptageNil(){
		int nil = 0;
		if(inf!=null){
			nil+=inf.comptageNil();
		}
		else{
			nil++;
		}
		if(eq!=null){
			nil+=eq.comptageNil();
		}
		else{
			nil++;
		}
		if(sup!=null){
			nil+=sup.comptageNil();
		}
		else{
			nil++;
		}
		return nil;
	}
	
	public int hauteur(){
		if(estFeuille()){
			return 0;
		}
		int h=0;
		int hinf=0;
		int heq=0;
		int hsup=0;
		
		if(inf!=null){
			hinf=inf.hauteur();
		}
		if(eq!=null){
			heq=eq.hauteur();
		}
		if(sup!=null){
			hsup=sup.hauteur();
		}
		
		h=Math.max(h, hinf);
		h=Math.max(h, heq);
		h=Math.max(h, hsup);
		return h+1;
	}
	
	private List<Integer> profondeurList(List<Integer> list, int profondeur){
		if(estFeuille()){
			list.add(profondeur);
		}
		if(inf!=null){
			inf.profondeurList(list,profondeur+1);
		}
		if(eq!=null){
			eq.profondeurList(list,profondeur+1);
		}
		if(sup!=null){
			sup.profondeurList(list,profondeur+1);
		}
		
		return list;
	}
	
	public int profondeurMoyenne(){
		List<Integer> list = profondeurList(new ArrayList<Integer>(),0);
		int moy = 0;
		for(int p: list){
			moy+=p;
		}
		return moy/list.size();
	}
	
	public int prefixe(String prefixe){
		return 0;
	}
	
	private void suppressionRec(String mot, List<Hybride> chemin){
		char c = mot.charAt(0);
		if(c<alpha){
			if(inf!=null){
				chemin.add(this);
				inf.suppressionRec(mot,chemin);
			}
			return;
		}
		if(c>alpha){
			if(sup!=null){
				chemin.add(this);
				sup.suppressionRec(mot,chemin);
			}
			return;
		}
		if(mot.length()==1){
			if(val>=0){
				chemin.add(this);
			}
			return;
		}
		if(eq!=null){
			chemin.add(this);
			eq.suppressionRec(mot.substring(1),chemin);
		}
		return;
	}
	
	public void suppression(String mot){
		if(alpha==' '){
			return;
		}
		List<Hybride> list = new ArrayList<Hybride>();
		suppressionRec(mot, list);
		if(list.size()>0){
			if(list.get(list.size()-1).estFeuille()){
				list.get(list.size()-2).setEq(null);
				int longueur = mot.length();
				int indice=0;
				longueur--;
				for(int i = list.size()-2; i>=1; i--){
					if(list.get(i).estFeuille() && list.get(i).getVal()==-1){
						list.get(i-1).setEq(null);
					}
					else{
						return;
					}
					longueur--;
					if(longueur<=2){
						indice=i-1;
						break;
					}
				}
				if(longueur==2){
					if(list.get(indice).estFeuille() && list.get(indice).getVal()==-1){
						if(list.get(indice-1).getInf()==list.get(indice)){
							list.get(indice-1).setInf(null);
						}
						else{
							list.get(indice-1).setSup(null);
						}
					}
				}
				return;
			}
			list.get(list.size()-1).setVal(-1);
			return;
		}
	}
}
