package lecture;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import tries.patricia.Patricia;

public class ShakespeareArbre{
	private Patricia p = LecturePatricia.lecture();
	
	@Test
	public void constructionPatricia(){
		LecturePatricia.lecture();
	}
	
	@Test
	public void ajoutMotFrancaisPatricia(){
		p.insert("anticonstitutionnelement");
	}
	
	@Test
	public void rechercheMotPatricia(){
		p.recherche("plead");
	}
	
	@Test
	public void supprimeMotPatricia(){
		List<String> listeSupp = Arrays.asList("zenelophon","the","comedy","of","errors","act","i","scene","i");
		for(String s : listeSupp){
			p.suppression(s);
		}
	}
}
