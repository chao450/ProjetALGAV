package lecture;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import tries.hybride.Hybride;
import tries.patricia.Patricia;

public class ShakespeareArbre{
	private Patricia patricia = Lecture.lectureSuccessifPatricia();
	private Patricia patriciaFusion = Lecture.lectureFusionPatricia();
	private Hybride hybride = Lecture.lectureSuccessifHybride();
	
	@Test
	public void patriciaConstructionAjoutSuccessifs(){
		Lecture.lectureSuccessifPatricia();
	}
	
	@Test
	public void patriciaConstructionFusion(){
		Lecture.lectureFusionPatricia();
	}
	
	@Test
	public void patriciaAjoutMotFrancais(){
		patricia.insert("anticonstitutionnelement");
	}
	
	@Test
	public void patriciaRechercheMot(){
		patricia.recherche("comedy");
	}
	
	@Test
	public void patriciaSupprimeMots(){
		List<String> listeSupp = Arrays.asList("zenelophon","the","comedy","of","errors","act","i","scene","i");
		for(String s : listeSupp){
			patricia.suppression(s);
		}
	}
	
	@Test
	public void patriciaVerif(){
		System.out.println("----Patricia----");
		System.out.println("Nb mots inserer: "+Lecture.verif(patricia));
		System.out.println("Nb mots dans Patricia: "+patricia.comptageMots());
		System.out.println("Nb pointeur nil: "+patricia.comptageNil());
		System.out.println("Profondeur moyenne: "+patricia.profondeurMoyenne());
		System.out.println("Hauteur: "+patricia.hauteur());
		
		System.out.println("\n----Patricia Fusion----");
		System.out.println("Nb mots inserer: "+Lecture.verif(patriciaFusion));
		System.out.println("Nb mots dans Patricia: "+patriciaFusion.comptageMots());
		System.out.println("Nb pointeur nil: "+patriciaFusion.comptageNil());
		System.out.println("Profondeur moyenne: "+patriciaFusion.profondeurMoyenne());
		System.out.println("Hauteur: "+patriciaFusion.hauteur());
	}
	
	@Test
	public void hybrideConstructionAjoutSuccessifs(){
		Lecture.lectureSuccessifHybride();
	}
	
	@Test
	public void hybrideAjoutMotFrancais(){
		hybride.ajoutMot("anticonstitutionnelement");
	}
	
	@Test
	public void hybrideRechercheMot(){
		hybride.recherche("comedy");
	}
	
	@Test
	public void hybrideSupprimeMots(){
		List<String> listeSupp = Arrays.asList("zone","comedy","of","errors","act","i","scene","i");
		for(String s : listeSupp){
			hybride.suppression(s);
		}
	}
	
	@Test
	public void hybrideVerif(){
		System.out.println("\n----Hybride----");
		System.out.println("Nb mots inserer: "+Lecture.verif(hybride));
		System.out.println("Nb mots dans Hybride: "+hybride.listeMot().size());
		System.out.println("Nb pointeur nil: "+hybride.comptageNil());
		System.out.println("Profondeur moyenne: "+hybride.profondeurMoyenne());
		System.out.println("Hauteur: "+hybride.hauteur());
	}
}
