package lecture;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import tries.hybride.Hybride;
import tries.patricia.Patricia;

public class Lecture{
	
	public static Patricia lectureSuccessifPatricia(){
		Patricia patricia = new Patricia();
		try{
			File repertoire = new File("Shakespeare");
			if(repertoire.isDirectory()){
				String[] fichier = repertoire.list();
				for(String s : fichier){
					File file = new File(repertoire+"/"+s);
					FileReader fr = new FileReader(file);
					BufferedReader br = new BufferedReader(fr);
					String line = br.readLine();
					while(line!=null){
						patricia.insert(line);
						line = br.readLine();
					}
					br.close();
					fr.close();
				}
			}
			else{
				System.out.println("Directory not found");
			}
		}catch(IOException e){}
		return patricia;
	}
	
	public static Patricia lectureFusionPatricia(){
		Patricia patricia = new Patricia();
		try{
			File repertoire = new File("Shakespeare");
			if(repertoire.isDirectory()){
				String[] fichier = repertoire.list();
				for(String s : fichier){
					Patricia patAFusionner = new Patricia();
					File file = new File(repertoire+"/"+s);
					FileReader fr = new FileReader(file);
					BufferedReader br = new BufferedReader(fr);
					String line = br.readLine();
					while(line!=null){
						patAFusionner.insert(line);
						line = br.readLine();
					}
					br.close();
					fr.close();
					patricia.fusion(patAFusionner);
				}
			}
			else{
				System.out.println("Directory not found");
			}
		}catch(IOException e){}
		return patricia;
	}
	
	public static int verif(Patricia patri){
		int cpt=0;
		Set<String> set = new HashSet<String>();
		try{
			File repertoire = new File("Shakespeare");
			if(repertoire.isDirectory()){
				String[] fichier = repertoire.list();
				for(String s : fichier){
					File file = new File(repertoire+"/"+s);
					FileReader fr = new FileReader(file);
					BufferedReader br = new BufferedReader(fr);
					String line = br.readLine();
					while(line!=null){
						if(!patri.recherche(line)){
							System.out.println("Error");
						}
						cpt++;
						set.add(line);
						line = br.readLine();
					}
					br.close();
					fr.close();
				}
			}
			else{
				System.out.println("Directory not found");
			}
		}catch(IOException e){}
		System.out.println("Nb de mots sans compter les doublons : "+set.size());
		return cpt;
	}
	
	public static Hybride lectureSuccessifHybride(){
		Hybride hybride = new Hybride();
		try{
			File repertoire = new File("Shakespeare");
			if(repertoire.isDirectory()){
				String[] fichier = repertoire.list();
				for(String s : fichier){
					File file = new File(repertoire+"/"+s);
					FileReader fr = new FileReader(file);
					BufferedReader br = new BufferedReader(fr);
					String line = br.readLine();
					while(line!=null){
						hybride.ajoutMot(line);
						line = br.readLine();
					}
					br.close();
					fr.close();
				}
			}
			else{
				System.out.println("Directory not found");
			}
		}catch(IOException e){}
		return hybride;
	}
	
	public static int verif(Hybride hyb){
		int cpt=0;
		Set<String> set = new HashSet<String>();
		try{
			File repertoire = new File("Shakespeare");
			if(repertoire.isDirectory()){
				String[] fichier = repertoire.list();
				for(String s : fichier){
					File file = new File(repertoire+"/"+s);
					FileReader fr = new FileReader(file);
					BufferedReader br = new BufferedReader(fr);
					String line = br.readLine();
					while(line!=null){
						if(!hyb.recherche(line)){
							System.out.println("Error");
						}
						cpt++;
						set.add(line);
						line = br.readLine();
					}
					br.close();
					fr.close();
				}
			}
			else{
				System.out.println("Directory not found");
			}
		}catch(IOException e){}
		System.out.println("Nb de mots sans compter les doublons : "+set.size());
		return cpt;
	}
}
