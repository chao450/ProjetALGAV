package lecture;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import tries.patricia.Patricia;

public class LecturePatricia{
	
	public static Patricia lecture(){
		Patricia patricia = new Patricia();
		try{
			File repertoire = new File("Shakespeare");
			if(repertoire.isDirectory()){
				String[] fichier = repertoire.list();
				for(String s : fichier){
					File file = new File(repertoire+"/"+s);
					FileReader fr = new FileReader(file);
					BufferedReader br = new BufferedReader(fr);
					String line = br.readLine();
					
					while(line!=null){
						patricia.insert(line);
						line = br.readLine();
					}
					br.close();
					fr.close();
				}
			}
			else{
				System.out.println("Directory not found");
			}
		}catch(IOException e){}

		return patricia;
	}
}
