package lecture;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import tries.patricia.Patricia;

public class ShakespeareArbre{
	private Patricia patricia = Lecture.lectureSuccessif();
	private Patricia patriciaFusion = Lecture.lectureFusion();
	
	@Test
	public void patriciaConstructionAjoutSuccessifs(){
		Lecture.lectureSuccessif();
	}
	
	@Test
	public void patriciaConstructionFusion(){
		Lecture.lectureFusion();
	}
	
	@Test
	public void patriciaAjoutMotFrancais(){
		patricia.insert("anticonstitutionnelement");
	}
	
	@Test
	public void patriciaRechercheMot(){
		patricia.recherche("comedy");
	}
	
	@Test
	public void patriciaSupprimeMots(){
		List<String> listeSupp = Arrays.asList("zenelophon","the","comedy","of","errors","act","i","scene","i");
		for(String s : listeSupp){
			patricia.suppression(s);
		}
	}
	
	@Test
	public void patriciaVerif(){
		System.out.println("----Patricia----");
		System.out.println("Nb mots inserer: "+Lecture.verif(patricia));
		System.out.println("Nb mots dans Patricia: "+patricia.comptageMots());
		System.out.println("Nb pointeur nil: "+patricia.comptageNil());
		System.out.println("Profondeur moyenne: "+patricia.profondeurMoyenne());
		System.out.println("Hauteur: "+patricia.hauteur());
		
		System.out.println("\n----Patricia Fusion----");
		System.out.println("Nb mots inserer: "+Lecture.verif(patriciaFusion));
		System.out.println("Nb mots dans Patricia: "+patriciaFusion.comptageMots());
		System.out.println("Nb pointeur nil: "+patriciaFusion.comptageNil());
		System.out.println("Profondeur moyenne: "+patriciaFusion.profondeurMoyenne());
		System.out.println("Hauteur: "+patriciaFusion.hauteur());
		
	}
}
