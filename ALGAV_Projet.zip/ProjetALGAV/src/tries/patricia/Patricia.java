package tries.patricia;

import java.util.ArrayList;
import java.util.List;

/**
 * Patricia : LIN Chao
 * k longueur du mot à insérer
 * m nombre de mot de l'arbre
 * n nombre de noeuds de l'arbre
 **/

public class Patricia {
	private Node[] tab;
	private Node pere;

	private Patricia(Node pere) {
		tab = new Node[128];
		this.pere = pere;
	}

	public Patricia() {
		this(null);
	}
	
	/* Complexité comparaison de caractere: O(k)
	 * Boucle for qui parcours le mot
	 * Equals qui vérifie si le mot existe déjà
	 */
	private void insertAux(String mot) {
		int i = (int) mot.charAt(0); // on indice par le code ascii
		Node n = tab[i];
		if (n == null) {
			Node newNode = new Node(mot);
			tab[i] = newNode;
			return;
		}
		// on verifie si on a déja le mot dans le tab
		if (n.getClef().equals(mot)) {
			return;
		}
		// si le mot est plus court que la clef, on est sure de tomber sur l'espace,
		// donc un caractère différent
		for (int c = 1; c < n.getLength(); c++) {
			if (mot.charAt(c) != n.getClef().charAt(c)) {
				String resteMot = mot.substring(c);
				if (n.getFils() == null) {
					//On creer un nouveau tableau fils avec le suffixe de la clef et du mot
					//Le prefixe devient la clef
					Patricia patfils = new Patricia(n);
					patfils.insertAux(resteMot);
					patfils.insertAux(n.getClef().substring(c));
					n.setClef(n.getClef().substring(0, c));
					n.setFils(patfils);
					return;
				} else {
					Patricia patfils = new Patricia(n);
					patfils.insertAux(resteMot);
					Node newNode = new Node(n.getClef().substring(c));
					newNode.setFils(n.getFils());
					patfils.getTab()[(int)n.getClef().charAt(c)]=newNode;
					n.setClef(n.getClef().substring(0, c));
					n.setFils(patfils);
					return;
				}
			}
		}
		//Le mot est plus long que la clef, on insert le suffixe aux tableau fils
		String resteMot = mot.substring(n.getLength());
		n.getFils().insertAux(resteMot);
	}

	public void insert(String mot) {
		//evite que le mot qu'on insert ne met pas le caractere de fin de mot
		if (mot.charAt(mot.length() - 1) != ' ') {
			mot = mot + ' ';
		}
		this.insertAux(mot);
	}

	// Pour le test de l'exemple de base
	public Node[] insertPhrase(String phrase) {
		int debutMot = 0;
		for (int i = 0; i < phrase.length(); i++) {
			if (phrase.charAt(i) == ' ') {
				String mot = phrase.substring(debutMot, i + 1);
				if (mot.contains(",")) {
					mot = mot.replace(",", "");
					this.insert(",");
				}
				this.insert(mot);
				debutMot = i + 1;
			}
		}
		this.insert(phrase.substring(debutMot, phrase.length()));
		return tab;
	}

	//getter
	public Node[] getTab() {
		return tab;
	}

	public Node getPere() {
		return pere;
	}
	
	private void setTabI(Node n, int i){
		tab[i]=n;
	}
	
	private Node getTabI(int i){
		return tab[i];
	}
	
	//Affichage print, on donne un id pour une affichage qui sépare bien la profondeur entre tableau
	private void printTabRec(int id) {
		for (Node n : tab) {
			if (n != null) {
				for (int i = 0; i < id; i++) {
					System.out.print("\t");
				}
				if (n.getFils() != null) {
					System.out.println(n.getClef() + "---Patricia " + id);
					n.getFils().printTabRec(id+1);
				} else {
					System.out.println(n.getClef() + "---Patricia " + id);
				}
			}
		}
	}
	
	//on commence par une profondeur de 0
	public void printTab(){
		printTabRec(0);
	}

	/* Complexité comparaison de caractere: O(k)
	 * Boucle for qui parcours le mot
	 * Equals qui vérifie si c'est le mot qu'on cherche
	 */
	public boolean recherche(String mot) {
		if (mot.charAt(mot.length() - 1) != ' ') {
			mot = mot + ' ';
		}
		int i = (int) mot.charAt(0);
		Node n = tab[i];
		if (n == null) {
			return false;
		}
		if (n.getClef().equals(mot)) {
			return true;
		}
		// si le mot est plus long que la clef, on cherche dans les fils de la clef
		if (mot.length() >= n.getLength()) {
			for (int c = 1; c < n.getLength(); c++) {
				if (mot.charAt(c) != n.getClef().charAt(c)) {
					return false;
				}
			}
			if (n.getFils() == null) {
				return false;
			}
			return n.getFils().recherche(mot.substring(n.getLength()));
		}
		// si le mot est strictement plus court que la clef, c'est qu'on n'a pas ce mot
		return false;
	}

	// on parcours tous les noeuds et les fils de ces noeuds s'il existe
	// Complexite nb de noeuds parcouru: O(n)
	public int comptageMots() {
		int cpt = 0;
		for (Node n : tab) {
			if (n != null) {
				if (n.getFils() == null) {
					cpt++;
				} else {
					cpt += n.getFils().comptageMots();
				}
			}
		}
		return cpt;
	}

	// methode auxiliaire qui garde le prefixe en paramètre pour reconstruire le mot
	// parcours tous les noeuds et leur fils s'il existe
	// Complexite nb de noeuds parcouru: O(n)
	private List<String> construitMots(String prefixe) {
		List<String> list = new ArrayList<String>();
		for (Node n : tab) {
			if (n != null) {
				if (n.getFils() == null) {
					list.add(prefixe + n.getClef());
				} else {
					list.addAll(n.getFils().construitMots(prefixe + n.getClef()));
				}
			}
		}
		return list;
	}

	public List<String> listeMots() {
		List<String> list = new ArrayList<String>();
		list.addAll(this.construitMots(""));
		return list;
	}

	// parcours tous les noeuds et leur fils s'il existe
	// Complexite nb de noeuds parcouru: O(n)
	public int comptageNil() {
		int nil = 0;
		for (Node n : tab) {
			if (n == null) {
				nil++;
			} else {
				if (n.getFils() != null) {
					nil += n.getFils().comptageNil();
				} else {
					nil++;
				}
			}
		}
		return nil;
	}
	
	// On fait une liste avec la hauteur de chaque feuille et on prend le max
	// On parcours tous les noeuds et leur fils s'il existe
	// Complexite nb de noeuds parcouru: O(n)
	private void listeHauteur(List<Integer> hauteurs, int haut){
		boolean feuille = true;
		for (Node n : tab) {
			if (n != null) {
				if (n.getFils() != null) {
					feuille = false;
					n.getFils().listeHauteur(hauteurs, haut+1);
				}
			}
		}
		if(feuille){
			hauteurs.add(haut);
		}
	}
	
	public int hauteur() {
		boolean arbreVide = true;
		List<Integer> listeH = new ArrayList<Integer>();
		// on parcour d'abord une fois pour vérifier si c'est un arbre vide (hauteur=0)
		for (Node n : tab) {
			if (n != null) {
				arbreVide = false;
				if (n.getFils() != null) {
					n.getFils().listeHauteur(listeH, 2); // si on a un élément, on est à hauteur=1
														// si l'élément a un fils, on est à hauteur=2
				}
			}
		}
		if (arbreVide) {
			return 0;
		}
		int max = 0;
		for (int i : listeH) {
			if (i > max) {
				max = i;
			}
		}
		return max;
	}

	// On fait une liste avec la hauteur de chaque feuille et on prend la moyenne
	// On parcours tous les noeuds et leur fils s'il existe
	// Complexite nb de noeuds parcouru: O(n)
	private List<Integer> listeprofondeur(int p, List<Integer> l) {
		l.add(p);
		for (Node n : tab) {
			if (n != null) {
				if (n.getFils() != null) {
					n.getFils().listeprofondeur(p + 1, l);
				}
			}
		}
		return l;
	}

	public int profondeurMoyenne() {
		int moy = 0;
		List<Integer> list = new ArrayList<Integer>();
		list = listeprofondeur(0, list);
		for (int i : list) {
			moy += i;
		}
		return moy / list.size();
	}
	
	/*Complexité comparaison de caractere: O(k) avec prefixe comme mot
	 */
	public int prefixe(String prefixe) {
		int i = (int) prefixe.charAt(0);
		Node n = tab[i];
		if (n == null) {
			return 0;
		}
		if (n.getLength() < prefixe.length()) {
			for (int c = 1; c < n.getLength(); c++) {
				if (prefixe.charAt(c) != n.getClef().charAt(c)) {
					return 0;
				}
			}
			if (n.getFils() == null) {
				return 1;
			}
			return n.getFils().prefixe(prefixe.substring(n.getLength()));
		}
		for (int c = 1; c < prefixe.length(); c++) {
			if (prefixe.charAt(c) != n.getClef().charAt(c)) {
				return 0;
			}
		}
		if (n.getFils() == null) {
			return 1;
		}
		return n.getFils().comptageMots();
	}

	// fonction auxiliaire qui supprime le mot directement sans analyser la structure
	private Patricia suppressionEffectuer(String mot) {
		int i = (int) mot.charAt(0);
		Node n = tab[i];
		if (n == null) {
			return null;
		}
		if (n.getClef().equals(mot)) {
			tab[i] = null;
			return this;
		}
		if (mot.length() >= n.getLength()) {
			for (int c = 1; c < n.getLength(); c++) {
				if (mot.charAt(c) != n.getClef().charAt(c)) {
					return null;
				}
			}
			// si c'est le meme mot (pas de fils), c'est déjà vérifier dans le if
			// si c'est deux mots différents, on retourne null avec le if qui est dans le for
			// sinon, c'est un préfixe qui a un fils
			return n.getFils().suppressionEffectuer(mot.substring(n.getLength()));
		}
		return null;
	}
	
	private int comptageNoeuds(){
		int cpt=0;
		for (Node n : tab){
			if(n!=null){
				cpt++;
			}
		}
		return cpt;
	}
	
	/* Complexité comparaison de caractere: O(k)
	 * Parcours une fois un tableau[128] pour compter le nb de noeud
	 * Et une deuxieme fois pour la transformation
	 */
	public Patricia suppression(String mot) {
		if (mot.charAt(mot.length() - 1) != ' ') {
			mot = mot + ' ';
		}
		// On récupère le tableau où on a supprimer le mot (le suffixe)
		Patricia patAvecMot = this.suppressionEffectuer(mot);
		// le mot n'existe pas dans l'arbre
		if (patAvecMot == null) {
			return this;
		}
		// on fusionne les deux tableaux que dans le cas où ce n'est pas le tableau de profondeur 0
		// et que le tableau ne contient qu'un seul noeud
		// note: on parcours aux moins une fois 128 cases pour vérifier s'il il n'existe qu'un seul
		// noeud et une autre fois pour appliquer la fusion, mais on break dès qu'on a trouvé
		if (patAvecMot.comptageNoeuds() == 1 && patAvecMot.getPere() != null) {
			for (Node n : patAvecMot.getTab()) {
				if (n != null) {
					Node nodePere = patAvecMot.getPere();
					nodePere.setClef(nodePere.getClef() + n.getClef());
					nodePere.setFils(n.getFils());
					break;
				}
			}
		}
		return this;
	}
	
	/* Complexite nb de comparaison de caractère: O(nk)
	 * On parcours chaque noeud et s'il n'est pas vide,
	 * on parcours le mots en entier dans le cas où il existe deux mots
	 * avec juste le dernier caractère différent
	 */
	
	public Patricia fusion(Patricia p){
		for(int i=0; i<p.getTab().length; i++){
			Node nodeA = this.getTabI(i);
			Node nodeB = p.getTabI(i);
			// Le noeudA est null donc on peut directement lier le noeudB à l'emplacement i
			if(nodeA==null && nodeB!=null){
				this.setTabI(nodeB, i);
				continue;
			}
			if(nodeA!=null && nodeB!=null){
				// On récupère les clefs et les fils
				String clefA = nodeA.getClef();
				String clefB = nodeB.getClef();
				Patricia filsA = nodeA.getFils();
				Patricia filsB = nodeB.getFils();
				if(clefA.equals(clefB)){
					if(filsA==null && filsB==null){
						continue; // le meme mot
					}
					filsA.fusion(filsB);
					continue; //le meme prefixe
				}
				if(filsB==null){
					this.insertAux(clefB);
					continue; //le noeud B est un mot, on insert ce mot
				}
				if(filsA==null){ // le noeud A est un mot, on insert le mot de A dans la tab de B, en sachant que les noeuds A et B sont de meme indice
					p.insertAux(clefA);
					this.setTabI(p.getTabI(i), i);
					continue;
				}
				if(filsA!=null && filsB!=null){ // a et b sont tous des noeuds représentant des clefs
					boolean prefixeDifferent = false;
					for(int c=1; c<Math.min(clefA.length(),clefB.length());c++){
						// a et b sont ont des clefs de prefixe différent
						if(clefA.charAt(c)!=clefB.charAt(c)){
							//on creer un tableau fils qui fait le milieu des deux noeuds
							Patricia pat = new Patricia(nodeA);
							Node newNodeA = new Node(clefA.substring(c));
							Node newNodeB = new Node(clefB.substring(c));
							newNodeA.setFils(filsA);
							newNodeB.setFils(filsB);
							pat.setTabI(newNodeA, (int)clefA.charAt(c));
							pat.setTabI(newNodeB, (int)clefB.charAt(c));
							nodeA.setClef(clefA.substring(0, c));
							nodeA.setFils(pat);
							prefixeDifferent=true;
							break;
						}
					}
					if(prefixeDifferent==true){
						continue;
					}
					// le cas où les deux clefs sont pareil, c'est déjà traité plus haut par un equals
					if(clefA.length()<clefB.length()){
						//a et b a le meme prefixe, celui de A est plus court
						String reste = clefB.substring(clefA.length());
						Patricia tmp = new Patricia();
						nodeB.setClef(reste);
						int indice = (int)reste.charAt(0);
						tmp.setTabI(nodeB, indice);
						filsA.fusion(tmp);
					}
					else{
						//a et b a le meme prefixe, celui de B est plus court
						String reste = clefA.substring(clefB.length());
						Patricia tmp = new Patricia(nodeA);
						int indice = (int)reste.charAt(0);
						Node newNode = new Node(reste);
						newNode.setFils(filsA);
						tmp.setTabI(newNode, indice);
						nodeA.setClef(clefA.substring(0,clefB.length()));
						nodeA.setFils(tmp);
						nodeA.getFils().fusion(filsB);
					}
				}
			}
		}
		return this;
	}
	
	// donne la different des mots de deux patricia (verification si la fusion est correcte)
	public List<String> different(Patricia p){
		List<String> list = new ArrayList<String>();
		List<String> listA = this.listeMots();
		List<String> listB = p.listeMots();
		for(String s : listB){
			if(!listA.contains(s)){
				list.add(s);
			}
		}
		return list;
	}
}
